 



$(document).ready(function(){


  $('#select_js').hover(
      function() { $('#seleccion').show(); },
      function() { $('#seleccion').hide(); }
    );

});  



   


    
   

    



    
   

    
